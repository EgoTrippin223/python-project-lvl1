from brain_games.scripts.games.brain_progression import brain_prog

def main():
    brain_prog()

if __name__=="__main__":
    main()