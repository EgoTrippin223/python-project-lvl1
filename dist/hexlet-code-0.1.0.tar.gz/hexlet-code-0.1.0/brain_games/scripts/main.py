from brain_games.scripts.games.brain_progression import brain_prog



if __name__=="__main__":
    brain_prog()