#!/usr/bin/env/python

import prompt
from random import randint


def main():
    print("Welcome to the Brain Games!")
    user_name = prompt.string("May I have your name? ")
    print(f"Hello, {user_name}!")
    print("Answer 'yes' if the number is even, otherwise answer 'no'.")
    index = 0
    winscore = 3
    congrats = f"Congratulations, {user_name} !"
    while index < winscore:
        number = randint(1, 100)
        print("Question:", number)
        index += 1
        user_answer = prompt.string("Your answer: ")
        if number % 2 == 0:
            correct_answer = "yes"
        else:
            correct_answer = "no"
        if user_answer.lower() == correct_answer:
            print("Correct!")
            if index == winscore:
                print(congrats)
        else:
            print(
                f"{user_answer} is wrong answer :(. Correct answer was, {correct_answer}"
            )
            break


main()
